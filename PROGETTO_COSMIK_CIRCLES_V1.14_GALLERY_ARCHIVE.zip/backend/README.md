# Kosmik Circles backend

Minimal production-oriented backend using Python standard library + SQLite. No paid API or package is required for the core CMS/order/contact functionality.

## Local start (Windows PowerShell)

```powershell
$env:KOSMIK_ADMIN_PASSWORD = "CHANGE-ME-LONG-RANDOM-PASSWORD"
python backend/server.py
```

Open `http://127.0.0.1:8080/`.

## API

- `GET /api/health`
- `GET /api/content`
- `POST /api/messages`
- `POST /api/orders`
- `POST /api/admin/login`
- `GET /api/admin/orders` (Bearer token)
- `GET /api/admin/messages` (Bearer token)
- `POST /api/admin/content` (Bearer token)
- `POST /api/admin/orders/status` (Bearer token)
- `DELETE /api/admin/messages?id=...` (Bearer token)

SQLite database is created at `backend/data/kosmik.db`.

## Production notes

Set environment secrets on the server; never commit them. Put the app behind HTTPS/reverse proxy. Configure a real transactional email provider and a payment provider before accepting paid orders. The current order endpoint deliberately creates an unpaid order; it does not pretend that a payment occurred.
