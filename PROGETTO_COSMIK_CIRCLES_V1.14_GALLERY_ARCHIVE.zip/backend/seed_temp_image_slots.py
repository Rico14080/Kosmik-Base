#!/usr/bin/env python3
"""Seed every image-capable slot with the bundled temporary test image.
Use only in a disposable/local test database.
"""
from pathlib import Path
import json, shutil, sqlite3
ROOT=Path(__file__).resolve().parents[1]
DB=ROOT/'backend'/'data'/'kosmik.db'
UPLOADS=ROOT/'backend'/'uploads'
SRC=ROOT/'TEMP_IMAGE_SLOT_TEST.webp'
if not DB.exists(): raise SystemExit('Start the server once first so the database exists.')
UPLOADS.mkdir(parents=True, exist_ok=True)
name='temp-slot-test.webp'
shutil.copy2(SRC, UPLOADS/name)
url=f'/backend/uploads/{name}'
c=sqlite3.connect(DB)
row=c.execute('SELECT content FROM site_content WHERE id=1').fetchone()
content=json.loads(row[0])
content.setdefault('home',{})['heroImage']=url
content.setdefault('us',{})['photo']=url
content.setdefault('us',{}).setdefault('soundImages',[{}, {}, {}])
for i in range(3): content['us']['soundImages'][i]['image']=url
for p in content.get('shop',[]): p['image']=url
# The public API reads active shop items from the products table, so update those rows too.
c.execute('UPDATE products SET image=?, updated_at=CURRENT_TIMESTAMP WHERE active=1',(url,))
for g in content.get('gallery',[]): g['image']=url
content.setdefault('visuals',{})['liveBackgroundImage']=url
c.execute('UPDATE site_content SET content=? WHERE id=1',(json.dumps(content,ensure_ascii=False),))
c.commit(); c.close()
print('Temporary image assigned to all image-capable slots:',url)
