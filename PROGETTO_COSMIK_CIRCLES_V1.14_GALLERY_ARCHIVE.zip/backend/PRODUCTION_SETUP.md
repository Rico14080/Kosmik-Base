# Kosmik Circles — production setup

The code is ready for the remaining account/provider configuration. Do not put secrets in Git or the frontend.

## Required environment

- `KOSMIK_ADMIN_PASSWORD`: long random admin password.
- `PUBLIC_BASE_URL`: final HTTPS site origin.

## Optional until launch

- Stripe: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`.
- SMTP: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, `SITE_OWNER_EMAIL`.

## Stripe webhook

Create a webhook endpoint at `/api/stripe/webhook` and subscribe to `checkout.session.completed`. The endpoint verifies Stripe's signature before updating an order.

## Backups

Run `python backend/backup.py` before upgrades or deployments. Store copies outside the web root.
