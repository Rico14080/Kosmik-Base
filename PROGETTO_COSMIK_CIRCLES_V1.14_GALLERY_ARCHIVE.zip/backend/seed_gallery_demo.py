#!/usr/bin/env python3
"""Create one clearly marked local demo gallery archive for testing.
Uses a real image already present in the project. Safe to delete later from Admin.
"""
from pathlib import Path
import shutil
import sqlite3
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DB = HERE / 'data' / 'kosmik.db'
MEDIA = HERE / 'media'
UPLOADS = HERE / 'uploads'
MEDIA.mkdir(parents=True, exist_ok=True)
UPLOADS.mkdir(parents=True, exist_ok=True)
source = next(iter(ROOT.glob('*.webp')), None)
if not source:
    raise SystemExit('No local WEBP image found.')
con = sqlite3.connect(DB)
con.row_factory = sqlite3.Row
row = con.execute("SELECT id FROM gallery_albums WHERE title LIKE 'TEMP / Archive Test%'").fetchone()
if row:
    print('Demo archive already exists:', row['id'])
    con.close()
    raise SystemExit(0)
stamp = datetime.now(timezone.utc).isoformat()
cover_name = 'temp-gallery-cover.webp'
shutil.copy2(source, UPLOADS / cover_name)
stored = f'temp-gallery-{source.stem}.webp'
shutil.copy2(source, MEDIA / stored)
con.execute("INSERT INTO gallery_albums(title,slug,date,location,venue,description,cover_image,sort_order,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (
    'TEMP / Archive Test', 'temp-archive-test', '2026-09-02', 'Demo location', 'Demo venue',
    'Temporary folder used to verify photo/video archive downloads.', f'/backend/uploads/{cover_name}', -100, 1, stamp, stamp))
aid = con.execute('SELECT last_insert_rowid()').fetchone()[0]
con.execute("INSERT INTO gallery_media(album_id,original_name,stored_name,media_type,mime_type,size_bytes,sort_order,active,created_at) VALUES(?,?,?,?,?,?,?,?,?)", (
    aid, source.name, stored, 'image/webp', 'image/webp', (MEDIA / stored).stat().st_size, 0, 1, stamp))
con.commit(); con.close()
print('Created demo gallery album', aid)
